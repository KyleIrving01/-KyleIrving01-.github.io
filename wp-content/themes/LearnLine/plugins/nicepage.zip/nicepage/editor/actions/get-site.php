<?php
defined('ABSPATH') or die;

class NpGetSiteAction extends NpAction {

    /**
     * Get pages json in Nicepage-editor format
     *
     * @return array
     * @throws Exception
     */
    private static function _getPages() {
        // all post from db : posts_per_page => -1
        $query_options = array(
            'post_type' => 'page',
            'posts_per_page' => -1,
            'order' => 'DESC',
            'orderby' => 'modified',
            'post_status' => 'any',
            'meta_key' => '_np_html',
        );

        $query = new WP_Query;
        $posts = $query->query($query_options);

        $result = array();

        foreach ($posts as $post) {
            if (NpEditor::isAllowedForEditor($post)) {
                $current_page = self::getPost($post);
                $current_page['publishUrl'] = $current_page['publicUrl'];
                $result[] = $current_page;
            }
        }

        return $result;
    }

    /**
     * Get files json in Nicepage-editor format
     *
     * @return array
     * @throws Exception
     */
    private static function _getFiles() {
        $allowed_types_attachment = get_allowed_mime_types();
        $file_without_images = array();
        foreach ($allowed_types_attachment as $allowed_type) {
            if ($allowed_type !== 'image/jpeg' && $allowed_type !== 'image/png' && $allowed_type !== 'image/bmp' && $allowed_type !== 'image/tiff' && $allowed_type !== 'image/x-icon' && $allowed_type !== 'image/gif') {
                $file_without_images[] = $allowed_type;
            }
        }
        $query_options = array(
            'post_type' => 'attachment',
            'post_mime_type' => $file_without_images,
            'posts_per_page' => -1,
            'order' => 'ASC',
            'orderby' => 'modified',
            'post_status' => 'any',
        );

        $result = array();

        $files = get_posts($query_options);

        foreach ($files as $file) {
            $current_file = self::getFile($file);
            $result[] = $current_file;
        }

        return $result;
    }

    /**
     * Get site
     *
     * @return array
     */
    public static function getSite() {

        $site_settings = NpMeta::get('site_settings');

        // backeard for broken back to top and captcha script.
        $s = json_decode($site_settings);
        if ($s) {
            $i = 0;
            while ($i < 100) {
                $original = clone $s;
                $s1 = stripslashes_deep($s);
                if (json_encode($original) == json_encode($s1)) {
                    break;
                }
                $s = $s1;
                $i++;
            }
            $site_settings = json_encode($s);
        }

        if (!$site_settings) {
            $site_settings = '{}';
        }

        return array(
            'title' => get_bloginfo('name'),
            'publicUrl' => get_home_url(),
            'id' => 1,
            'order' => 1,
            'status' => 2,
            'items' => self::_getPages(),
            'files' => self::_getFiles(),
            'settings' => $site_settings,
            'isFullLoaded' => true,
        );
    }

    /**
     * Process action entrypoint
     *
     * @return array
     */
    public static function process() {

        return array(
            'result' => 'done',
            'data' => self::getSite(),
        );
    }
}
NpAction::add('np_get_site', 'NpGetSiteAction');